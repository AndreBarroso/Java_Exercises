# Java_Exercises

Aqui encontram-se os exercícios de fixação resolvidos durante a aceleração em Java realizado na Codenation/Java.
