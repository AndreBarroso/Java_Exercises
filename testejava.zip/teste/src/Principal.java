public class Principal {
    public static void main(String[] args) {
       char letra = 97;

       String palavra = "Andre";

       int  x = (int) palavra.charAt(1);


        char letra2 = (char) (letra + 3);

       System.out.println(x) ;

    }
}
